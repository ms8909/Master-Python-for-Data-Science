list1=[1,5,67,2,43,6,4,2,2,4,6,2,1,68,5,4]

x1=list1[0]
x2=list1[1]

for i in range(0,len(list1)):
    print=[i]
    if x1>x2:
     x1=list1[1]
     x2=list1[2]