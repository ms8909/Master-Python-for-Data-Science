print("Enter 'true' or 'False' ")
inputA1=bool(input())
print("Enter 'true' or 'False' ")
inputB1=bool(input())

if inputA1==inputB1:
    print(0)
else:
    inputA1!=inputB2:
    print("1")
