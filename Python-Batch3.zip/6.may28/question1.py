names=["alan", "john", "taniaz", "ahmad", "ali", "muddassar", "raheel", "hamza"]
age=[12, 13, 14, 15, 16, 13, 13]
people=[]
for i in range(len(names)):
    people.append({"name":names [i] , "age":age [i]})
    print("peolpe = ", people)
